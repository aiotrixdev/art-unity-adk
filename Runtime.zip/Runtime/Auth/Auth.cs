// using System;
// using System.Collections.Generic;
// using System.Text;
// using System.Threading.Tasks;
// using Newtonsoft.Json;
// using Newtonsoft.Json.Linq;
// using UnityEngine;
// using UnityEngine.Networking;

// namespace ART.ADK
// {
//     /// <summary>
//     /// Singleton authentication manager handling JWT token lifecycle.
//     /// </summary>
//     internal class Auth
//     {
//         private static Auth _instance;
//         private static readonly object _lock = new object();

//         public CredentialStore _credentials;
//         private AuthData _authData = new AuthData();

//         public string UserId
//         {
//             get
//             {
//                 if (string.IsNullOrEmpty(_authData.AccessToken)) return null;
//                 try
//                 {
//                     var payload = DecodeJWTPayload(_authData.AccessToken);
//                     return payload.TryGetValue("sub", out var sub) ? sub?.ToString() : null;
//                 }
//                 catch { return null; }
//             }
//         }

//         public string Username
//         {
//             get
//             {
//                 if (string.IsNullOrEmpty(_authData.AccessToken)) return null;
//                 try
//                 {
//                     var payload = DecodeJWTPayload(_authData.AccessToken);
//                     if (payload.TryGetValue("name", out var n)) return n?.ToString();
//                     if (payload.TryGetValue("username", out var u)) return u?.ToString();
//                     return UserId;
//                 }
//                 catch { return null; }
//             }
//         }

//         private Auth(CredentialStore credentials)
//         {
//             _credentials = credentials;
//         }

//         public static Auth GetInstance(CredentialStore credentials = null)
//         {
//             lock (_lock)
//             {
//                 if (_instance == null)
//                 {
//                     if (credentials == null)
//                         throw new ARTForbiddenException("Auth not initialised - provide credentials on first call");
//                     _instance = new Auth(credentials);
//                 }
//                 return _instance;
//             }
//         }

//         public static void Reset()
//         {
//             lock (_lock) { _instance = null; }
//         }

//         public async Task<AuthData> Authenticate(bool forceAuth = false)
//         {
//             if (!forceAuth && !string.IsNullOrEmpty(_authData.AccessToken) && !IsTokenExpired(_authData.AccessToken))
//                 return _authData;

//             // Refresh credentials via hook if present
//             // if (_credentials.GetCredentials != null)
//             // {
//             //     var cred = _credentials.GetCredentials();
//             //     _credentials.AccessToken = cred.AccessToken;
//             //     _credentials.ClientID = cred.ClientID;
//             //     _credentials.ClientSecret = cred.ClientSecret;
//             //     _credentials.OrgTitle = cred.OrgTitle;
//             //     _credentials.Environment = cred.Environment;
//             //     _credentials.ProjectKey = cred.ProjectKey;
//             // }

//             if (string.IsNullOrEmpty(_credentials.OrgTitle) ||
//                 string.IsNullOrEmpty(_credentials.Environment) ||
//                 string.IsNullOrEmpty(_credentials.ProjectKey))
//             {
//                 throw new ARTAuthenticationException("OrgTitle, Environment and ProjectKey are required");
//             }

//             // Try refresh token first
//             var refreshInfo = GetRefreshTokenExpiryInfo(_authData.RefreshToken);
//             if (!refreshInfo.expired)
//                 return await RefreshAuthToken();

//             return await GenerateAuthToken();
//         }

//         public AuthData GetAuthData() => _authData;
//         public CredentialStore GetCredentials() => _credentials;

//         private async Task<AuthData> GenerateAuthToken()
//         {
//             if (string.IsNullOrEmpty(_credentials.AccessToken))
//             {
//                 if (string.IsNullOrEmpty(_credentials.ClientID) || string.IsNullOrEmpty(_credentials.ClientSecret))
//                     throw new ARTAuthenticationException("ClientID and ClientSecret required when AccessToken is absent");
//             }

//             var url = $"{ArtConstants.BASE_URL}/auth/token";
//             using var request = new UnityWebRequest(url, "POST");
//             request.downloadHandler = new DownloadHandlerBuffer();

//             request.SetRequestHeader("Client-Id", _credentials.ClientID);
//             request.SetRequestHeader("Client-Secret", _credentials.ClientSecret);
//             request.SetRequestHeader("X-Org", _credentials.OrgTitle);
//             request.SetRequestHeader("Environment", _credentials.Environment);
//             request.SetRequestHeader("ProjectKey", _credentials.ProjectKey);

//             if (!string.IsNullOrEmpty(_credentials.AccessToken))
//                 request.SetRequestHeader("T-pass", _credentials.AccessToken);
//             if (_credentials.Config?.AuthToken != null)
//                 request.SetRequestHeader("X-pass", _credentials.Config.AuthToken);

//             var op = request.SendWebRequest();
//             while (!op.isDone) await Task.Yield();

//             if (request.result != UnityWebRequest.Result.Success)
//                 throw new ARTAuthenticationException(request.error);

//             var json = JObject.Parse(request.downloadHandler.text);
//             var tokenData = json["data"] as JObject;
//             if (tokenData == null)
//                 throw new ARTAuthenticationException("Unexpected token response shape");

//             _authData = new AuthData
//             {
//                 AccessToken = tokenData["access_token"]?.ToString() ?? "",
//                 RefreshToken = tokenData["refresh_token"]?.ToString() ?? ""
//             };
//             return _authData;
//         }

//         private async Task<AuthData> RefreshAuthToken()
//         {
//             if (string.IsNullOrEmpty(_credentials.AccessToken) && string.IsNullOrEmpty(_credentials.ClientID))
//                 throw new ARTAuthenticationException("ClientID required when AccessToken is absent");

//             var url = $"{ArtConstants.BASE_URL}/auth/token/refresh";
//             var body = JsonConvert.SerializeObject(new { refresh_token = _authData.RefreshToken });
//             var bodyBytes = Encoding.UTF8.GetBytes(body);

//             using var request = new UnityWebRequest(url, "POST");
//             request.uploadHandler = new UploadHandlerRaw(bodyBytes);
//             request.downloadHandler = new DownloadHandlerBuffer();
//             request.SetRequestHeader("Content-Type", "application/json");
//             request.SetRequestHeader("Client-Id", _credentials.ClientID);
//             request.SetRequestHeader("X-Org", _credentials.OrgTitle);
//             request.SetRequestHeader("Environment", _credentials.Environment);
//             request.SetRequestHeader("ProjectKey", _credentials.ProjectKey);

//             var op = request.SendWebRequest();
//             while (!op.isDone) await Task.Yield();

//             if (request.responseCode == 500)
//             {
//                 try
//                 {
//                     var errJson = JObject.Parse(request.downloadHandler.text);
//                     if (errJson["error"]?.ToString() == "Failed to get WebSocket backend")
//                         throw new ARTServerException(errJson["error"].ToString());
//                 }
//                 catch (ARTServerException) { throw; }
//                 catch { }
//             }

//             if (request.result != UnityWebRequest.Result.Success)
//                 throw new ARTAuthenticationException(request.error);

//             var json = JObject.Parse(request.downloadHandler.text);
//             var tokenData = json["data"] as JObject;
//             if (tokenData == null)
//                 throw new ARTAuthenticationException("Unexpected refresh response shape");

//             _authData = new AuthData
//             {
//                 AccessToken = tokenData["access_token"]?.ToString() ?? "",
//                 RefreshToken = tokenData["refresh_token"]?.ToString() ?? ""
//             };
//             return _authData;
//         }

//         private bool IsTokenExpired(string token)
//         {
//             if (string.IsNullOrEmpty(token)) return true;
//             try
//             {
//                 var payload = DecodeJWTPayload(token);
//                 if (payload.TryGetValue("exp", out var expObj) && double.TryParse(expObj.ToString(), out var exp))
//                 {
//                     var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
//                     return exp < (now - 100);
//                 }
//             }
//             catch { }
//             return true;
//         }

//         private Dictionary<string, object> DecodeJWTPayload(string token)
//         {
//             var parts = token.Split('.');
//             if (parts.Length < 2)
//                 throw new ARTAuthenticationException("Malformed JWT");

//             var b64 = parts[1].Replace("-", "+").Replace("_", "/");
//             var pad = (4 - b64.Length % 4) % 4;
//             b64 += new string('=', pad);

//             var jsonBytes = Convert.FromBase64String(b64);
//             var jsonStr = Encoding.UTF8.GetString(jsonBytes);
//             return JsonConvert.DeserializeObject<Dictionary<string, object>>(jsonStr);
//         }

//         private (bool expired, double? exp, double remaining) GetRefreshTokenExpiryInfo(string token)
//         {
//             if (string.IsNullOrEmpty(token))
//                 return (true, null, 0);

//             var parts = token.Split('.');
//             if (parts.Length < 2 || !double.TryParse(parts[1], out var exp))
//                 return (true, null, 0);

//             var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
//             return (now >= exp, exp, exp - now);
//         }
//     }
// }

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;
using UnityEngine.Networking;
using ART.ADK;

namespace ART.ADK
{

    /// <summary>
    /// Singleton authentication manager handling JWT token lifecycle.
    /// </summary>
    internal class Auth
    {
        private static Auth _instance;
        private static readonly object _lock = new object();

        public CredentialStore _credentials;
        private AuthData _authData = new AuthData();

        // Dedup concurrent Authenticate() calls onto a single in-flight request.
        private Task<AuthData> _authenticationInFlight;
        private readonly object _flightLock = new object();

        private const long DefaultTimeoutMs = 30_000L;

        public string UserId
        {
            get
            {
                if (string.IsNullOrEmpty(_authData.AccessToken)) return null;
                try
                {
                    var payload = DecodeJWTPayload(_authData.AccessToken);
                    return payload.TryGetValue("sub", out var sub) ? sub?.ToString() : null;
                }
                catch { return null; }
            }
        }

        public string Username
        {
            get
            {
                if (string.IsNullOrEmpty(_authData.AccessToken)) return null;
                try
                {
                    var payload = DecodeJWTPayload(_authData.AccessToken);
                    if (payload.TryGetValue("name", out var n)) return n?.ToString();
                    if (payload.TryGetValue("username", out var u)) return u?.ToString();
                    return UserId;
                }
                catch { return null; }
            }
        }

        private Auth(CredentialStore credentials)
        {
            _credentials = credentials;
        }

        public static Auth GetInstance(CredentialStore credentials = null)
        {
            lock (_lock)
            {
                var existing = _instance;
                if (existing != null && credentials != null && IdentityChanged(existing._credentials, credentials))
                {
                    // Different identity: start fresh (drops old tokens).
                    _instance = new Auth(credentials);
                }
                else if (existing != null && credentials != null)
                {
                    existing._credentials = credentials;
                }

                if (_instance == null)
                {
                    if (credentials == null)
                        throw new ARTForbiddenException("Forbidden");
                    _instance = new Auth(credentials);
                }
                return _instance;
            }
        }

        public static void Reset()
        {
            lock (_lock) { _instance = null; }
        }

        // Mirrors the Kotlin/TS identity fields: OrgTitle, Environment, ProjectKey, ClientID.
        private static bool IdentityChanged(CredentialStore a, CredentialStore b)
        {
            return a.OrgTitle != b.OrgTitle ||
                   a.Environment != b.Environment ||
                   a.ProjectKey != b.ProjectKey ||
                   a.ClientID != b.ClientID;
        }

        public async Task<AuthData> Authenticate(bool forceAuth = false)
        {
            Task<AuthData> pending;
            bool owner = false;

            lock (_flightLock)
            {
                if (_authenticationInFlight != null)
                {
                    pending = _authenticationInFlight;
                }
                else
                {
                    pending = AuthenticateOnce(forceAuth);
                    _authenticationInFlight = pending;
                    owner = true;
                }
            }

            try
            {
                return await pending;
            }
            finally
            {
                if (owner)
                {
                    lock (_flightLock) { _authenticationInFlight = null; }
                }
            }
        }

        // Match the WebSocket gateway's grant selection when both are supplied.
        private bool UsesClientCredentials()
        {
            return !string.IsNullOrEmpty(_credentials.ClientID) &&
                   !string.IsNullOrEmpty(_credentials.ClientSecret);
        }

        public AuthData GetAuthData() => _authData;
        public CredentialStore GetCredentials() => _credentials;

        private async Task<AuthData> AuthenticateOnce(bool forceAuth)
        {
            if (!forceAuth && !string.IsNullOrEmpty(_authData.AccessToken) && !IsTokenExpired(_authData.AccessToken))
                return _authData;

            var c = _credentials;
            if (string.IsNullOrEmpty(c.OrgTitle) ||
                string.IsNullOrEmpty(c.Environment) ||
                string.IsNullOrEmpty(c.ProjectKey))
            {
                throw new ARTAuthenticationException("OrgTitle, Environment, and ProjectKey are required for authentication.");
            }

            // Client credentials renew through authentication, never through refresh.
            // Ignore legacy refresh tokens returned by older IDP deployments.
            if (UsesClientCredentials())
                return await GenerateAuthToken();

            if (!GetRefreshTokenExpiryInfo(_authData.RefreshToken).expired)
                return await RefreshAuthToken();

            return await GenerateAuthToken();
        }

        private struct TokenResult
        {
            public bool Ok;
            public int Status;
            public string StatusMessage;
            public JObject Body;
        }

        /// <summary>
        /// Sends the request, enforcing connectionTimeoutMs (default 30s),
        /// and returns status + parsed JSON body (null if body isn't JSON).
        /// </summary>
        private async Task<TokenResult> RequestToken(UnityWebRequest request)
        {
            long timeoutMs = _credentials.Config?.ConnectionTimeoutMs ?? DefaultTimeoutMs;
            var sw = Stopwatch.StartNew();

            var op = request.SendWebRequest();
            while (!op.isDone)
            {
                if (sw.ElapsedMilliseconds > timeoutMs)
                {
                    request.Abort();
                    throw new ARTAuthenticationException(
                        "Authentication timed out. Please check your connection and sign in again.");
                }
                await Task.Yield();
            }

            // Network-level failure (no HTTP response at all).
            if (request.result == UnityWebRequest.Result.ConnectionError)
                throw new ARTAuthenticationException(request.error);

            JObject body = null;
            try
            {
                var text = request.downloadHandler?.text;
                if (!string.IsNullOrEmpty(text)) body = JObject.Parse(text);
            }
            catch { body = null; }

            int status = (int)request.responseCode;
            bool ok = status >= 200 && status < 300;
            return new TokenResult
            {
                Ok = ok,
                Status = status,
                StatusMessage = request.error ?? "",
                Body = body
            };
        }

        private static string ErrorMessageFrom(TokenResult result)
        {
            var msg = result.Body?["message"]?.ToString();
            return !string.IsNullOrEmpty(msg)
                ? msg
                : $"HTTP {result.Status} {result.StatusMessage}";
        }

        private async Task<AuthData> GenerateAuthToken()
        {
            var c = _credentials;

            if (string.IsNullOrEmpty(c.AccessToken))
            {
                if (string.IsNullOrEmpty(c.ClientID) || string.IsNullOrEmpty(c.ClientSecret))
                    throw new ARTAuthenticationException("ClientID and ClientSecret are required when AccessToken is not present.");
            }

            // Match the JS ADK / Kotlin: always send client creds + scope headers,
            // and add T-pass (the user passcode) whenever an access token is present.
            var url = $"{ArtConstants.BASE_URL}/auth/token";
            using var request = new UnityWebRequest(url, "POST");
            request.downloadHandler = new DownloadHandlerBuffer();

            request.SetRequestHeader("Content-Type", "application/json");
            request.SetRequestHeader("Client-Id", c.ClientID ?? "");
            request.SetRequestHeader("Client-Secret", c.ClientSecret ?? "");
            request.SetRequestHeader("X-Org", c.OrgTitle);
            request.SetRequestHeader("Environment", c.Environment);
            request.SetRequestHeader("ProjectKey", c.ProjectKey);

            if (!string.IsNullOrEmpty(c.AccessToken))
                request.SetRequestHeader("T-pass", c.AccessToken);
            if (!string.IsNullOrEmpty(c.Config?.AuthToken))
                request.SetRequestHeader("X-pass", c.Config.AuthToken);

            var result = await RequestToken(request);
            if (!result.Ok)
                throw new AuthHttpError(ErrorMessageFrom(result), result.Status, result.Body);

            var data = result.Body?["data"] as JObject;
            var accessToken = data?["access_token"]?.ToString();
            if (string.IsNullOrEmpty(accessToken))
                throw new ARTAuthenticationException("Authentication did not return an access token. Please sign in again.");

            _authData = new AuthData
            {
                AccessToken = accessToken,
                RefreshToken = UsesClientCredentials() ? "" : (data["refresh_token"]?.ToString() ?? "")
            };
            return _authData;
        }

        private async Task<AuthData> RefreshAuthToken()
        {
            var c = _credentials;

            if (string.IsNullOrEmpty(c.AccessToken) && string.IsNullOrEmpty(c.ClientID))
                throw new ARTAuthenticationException("ClientID is required when AccessToken is not present.");

            var url = $"{ArtConstants.BASE_URL}/auth/token/refresh";
            var body = JsonConvert.SerializeObject(new { refresh_token = _authData.RefreshToken });
            var bodyBytes = Encoding.UTF8.GetBytes(body);

            using var request = new UnityWebRequest(url, "POST");
            request.uploadHandler = new UploadHandlerRaw(bodyBytes);
            request.downloadHandler = new DownloadHandlerBuffer();

            request.SetRequestHeader("Content-Type", "application/json");
            request.SetRequestHeader("X-Org", c.OrgTitle);
            request.SetRequestHeader("Environment", c.Environment);
            request.SetRequestHeader("ProjectKey", c.ProjectKey);

            if (!string.IsNullOrEmpty(c.ClientID))
                request.SetRequestHeader("Client-Id", c.ClientID);
            if (!string.IsNullOrEmpty(c.AccessToken))
                request.SetRequestHeader("T-pass", c.AccessToken);
            if (!string.IsNullOrEmpty(c.Config?.AuthToken))
                request.SetRequestHeader("X-pass", c.Config.AuthToken);

            var result = await RequestToken(request);
            if (!result.Ok)
            {
                var serverError = result.Body?["error"]?.ToString() ?? "";
                if (result.Status == 500 && serverError == "Failed to get WebSocket backend")
                {
                    // keep existing AccessToken + RefreshToken
                    throw new ARTServerException(string.IsNullOrEmpty(serverError) ? "Internal server error" : serverError);
                }
                throw new AuthHttpError(ErrorMessageFrom(result), result.Status, result.Body);
            }

            var data = result.Body?["data"] as JObject;
            var accessToken = data?["access_token"]?.ToString();
            if (string.IsNullOrEmpty(accessToken))
                throw new ARTAuthenticationException("Authentication refresh did not return an access token. Please sign in again.");

            _authData = new AuthData
            {
                AccessToken = accessToken,
                RefreshToken = UsesClientCredentials() ? "" : (data["refresh_token"]?.ToString() ?? "")
            };
            return _authData;
        }

        // ---------------- helpers ----------------

        private bool IsTokenExpired(string token)
        {
            if (string.IsNullOrEmpty(token)) return true;
            try
            {
                var payload = DecodeJWTPayload(token);
                if (payload.TryGetValue("exp", out var expObj) &&
                    long.TryParse(Convert.ToString(expObj, System.Globalization.CultureInfo.InvariantCulture), out var exp))
                {
                    var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                    // Treat as expired 30s early (matches Kotlin).
                    return exp <= now + 30;
                }
            }
            catch { }
            return true; // missing exp or undecodable => expired
        }

        private Dictionary<string, object> DecodeJWTPayload(string token)
        {
            var parts = token.Split('.');
            if (parts.Length < 2)
                throw new ARTAuthenticationException("Malformed JWT");

            var b64 = parts[1].Replace("-", "+").Replace("_", "/");
            var pad = (4 - b64.Length % 4) % 4;
            b64 += new string('=', pad);

            var jsonBytes = Convert.FromBase64String(b64);
            var jsonStr = Encoding.UTF8.GetString(jsonBytes);
            return JsonConvert.DeserializeObject<Dictionary<string, object>>(jsonStr);
        }

        /// <summary>
        /// The "refresh token" is treated as a raw numeric expiry value in its
        /// second dot-segment, NOT a JWT (same as Kotlin/TS).
        /// </summary>
        private (bool expired, long? exp, long remaining) GetRefreshTokenExpiryInfo(string token)
        {
            if (string.IsNullOrEmpty(token))
                return (true, null, 0);

            var parts = token.Split('.');
            var expStr = parts.Length > 1 ? parts[1] : "";
            if (!long.TryParse(expStr, out var exp) || exp == 0)
                return (true, null, 0);

            var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            return (now >= exp, exp, exp - now);
        }
    }
}
