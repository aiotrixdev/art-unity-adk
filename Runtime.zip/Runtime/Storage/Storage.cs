using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;
using UnityEngine.Networking;

namespace ART.ADK
{
    /// <summary>
    /// Phase-tagged storage failure. Mirrors the Kotlin/JS UploadError.
    /// </summary>
    public class UploadError : Exception
    {
        public string Phase { get; }
        public long? StatusCode { get; }

        public UploadError(
            string message,
            string phase,
            long? statusCode = null,
            Exception inner = null)
            : base(message, inner)
        {
            Phase = phase;
            StatusCode = statusCode;
        }
    }

    [Serializable]
    public sealed class UploadOptions
    {
        public string Filename;
        public string ContentType;
        public string ConfigType;
        public string ConfigId;
        public List<string> Scopes;
        public long? TtlSeconds;

        // Kotlin uses timeoutMs, not timeoutSeconds.
        public long? TimeoutMs;

        public Action<float> OnProgress;

        public string ThreadId;

        public UploadOptions()
        {
            ContentType = "application/octet-stream";
            ConfigType = "media";
            Scopes = new List<string>();
        }
    }

    [Serializable]
    public sealed class FileRef
    {
        public string FileId;
        public string Name;
        public string ReadUrl;
        public long Size;
        public string ContentType;
    }

    [Serializable]
    public sealed class ListOptions
    {
        public string ConfigType;
        public string ConfigId;
        public int? Page;
        public int? Limit;
         
        public string ThreadId;
    }

    [Serializable]
    public sealed class StorageFile
    {
        public string FileId;
        public string Name;
        public string ConfigType;
        public string ConfigId;
        public long Size;
        public string ContentType;
        public string Status;
        public string CreatedAt;
        public string ExpiresAt;
        public string ReadUrl;
    }

    [Serializable]
    public sealed class ListFilesResult
    {
        public List<StorageFile> Files = new List<StorageFile>();
        public int Total;
    }

    /// <summary>
    /// Authenticated ART storage client.
    ///
    /// Flow:
    /// 1. POST /upload/signed-url
    /// 2. PUT bytes to returned upload_url
    /// 3. POST /upload/confirm/{fileId}
    ///
    /// Mirrors the supplied Kotlin Storage implementation.
    /// </summary>
    public sealed class Storage
    {
        public async Task<FileRef> UploadFile(
            string path,
            UploadOptions options = null)
        {
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
                throw new UploadError(
                    "file does not exist",
                    "validate");

            options ??= new UploadOptions();

            if (string.IsNullOrWhiteSpace(options.Filename))
                options.Filename = Path.GetFileName(path);

            return await Upload(
                File.ReadAllBytes(path),
                options);
        }

        public async Task<FileRef> Upload(
            byte[] file,
            UploadOptions options = null)
        {
            if (file == null || file.Length == 0)
                throw new UploadError(
                    "file is empty",
                    "validate");

            options ??= new UploadOptions();

            CredentialStore credentials;

            try
            {
                credentials = Auth.GetInstance().GetCredentials();
            }
            catch (Exception ex)
            {
                throw new UploadError(
                    "call connect() before upload()",
                    "validate",
                    null,
                    ex);
            }

            string fileName =
                string.IsNullOrWhiteSpace(options.Filename)
                    ? "upload.bin"
                    : options.Filename;

            string contentType =
                string.IsNullOrWhiteSpace(options.ContentType)
                    ? "application/octet-stream"
                    : options.ContentType;

            string configId =
                string.IsNullOrWhiteSpace(options.ConfigId)
                    ? credentials.ProjectKey
                    : options.ConfigId;

            var init = await StorageCall(
                "signed-url",
                "POST",
                "/upload/signed-url",
                new
                {
                    config_type =
                        string.IsNullOrWhiteSpace(options.ConfigType)
                            ? "media"
                            : options.ConfigType,

                    config_id = configId,
                    file_name = fileName,
                    file_size = file.Length,
                    content_type = contentType,

                    scopes =
                        options.Scopes ??
                        new List<string>(),

                    ttl_seconds = options.TtlSeconds
                },
                options.TimeoutMs);

            string fileId =
                init["file_id"]?.ToString();

            string uploadUrl =
                init["upload_url"]?.ToString();

            if (string.IsNullOrEmpty(fileId) ||
                string.IsNullOrEmpty(uploadUrl))
            {
                throw new UploadError(
                    "signed-url missing file_id/upload_url",
                    "signed-url");
            }

            await PutToStorage(
                uploadUrl,
                file,
                contentType,
                options);

            var done = await StorageCall(
                "confirm",
                "POST",
                "/upload/confirm/" + Escape(fileId),
                null,
                options.TimeoutMs);

            var doneFile =
                done["file"] as JObject;

            return new FileRef
            {
                FileId = fileId,
                Name = fileName,

                ReadUrl =
                    done["read_url"]?.ToString()
                    ?? string.Empty,

                Size =
                    doneFile?["file_size"]?.Value<long?>()
                    ?? file.LongLength,

                ContentType = contentType
            };
        }

        public async Task<ListFilesResult> ListFiles(
            ListOptions options = null)
        {
            options ??= new ListOptions();

            var query = new List<string>();

            if (!string.IsNullOrEmpty(options.ConfigType))
            {
                query.Add(
                    "config_type=" +
                    Escape(options.ConfigType));
            }

            if (!string.IsNullOrEmpty(options.ConfigId))
            {
                query.Add(
                    "config_id=" +
                    Escape(options.ConfigId));
            }

            if (options.Page.HasValue)
            {
                query.Add(
                    "page=" +
                    options.Page.Value);
            }

            if (options.Limit.HasValue)
            {
                query.Add(
                    "limit=" +
                    options.Limit.Value);
            }

            string path =
                "/files" +
                (query.Count == 0
                    ? ""
                    : "?" + string.Join("&", query));

            var data = await StorageCall(
                "list",
                "GET",
                path);

            var result = new ListFilesResult
            {
                Total =
                    data["total"]?.Value<int?>()
                    ?? 0
            };

            var files =
                data["files"] as JArray;

            if (files != null)
            {
                foreach (var item in files)
                {
                    if (item is JObject file)
                        result.Files.Add(
                            ToStorageFile(file));
                }
            }

            return result;
        }

        public async Task<StorageFile> GetFile(
            string fileId,
            long? timeoutMs = null)
        {
            if (string.IsNullOrWhiteSpace(fileId))
            {
                throw new UploadError(
                    "file id is required",
                    "validate");
            }

            var data = await StorageCall(
                "get",
                "GET",
                "/file/" + Escape(fileId),
                null,
                timeoutMs);

            var file =
                data["file"] as JObject;

            if (file == null)
            {
                throw new UploadError(
                    "get response is missing file",
                    "get");
            }

            var output =
                ToStorageFile(file);

            output.ReadUrl =
                data["read_url"]?.ToString()
                ?? output.ReadUrl;

            return output;
        }

        public async Task DeleteFile(
            string fileId,
            bool hard = false,
            long? timeoutMs = null)
        {
            if (string.IsNullOrWhiteSpace(fileId))
            {
                throw new UploadError(
                    "file id is required",
                    "validate");
            }

            string path =
                "/file/" +
                Escape(fileId) +
                (hard ? "/hard" : "");

            await StorageCall(
                "delete",
                "DELETE",
                path,
                null,
                timeoutMs);
        }

        // ---------------------------------------------------------
        // Internals
        // ---------------------------------------------------------

        private static async Task<JObject> StorageCall(
            string operation,
            string method,
            string path,
            object body = null,
            long? timeoutMs = null)
        {
            CredentialStore credentials;

            try
            {
                credentials =
                    Auth.GetInstance()
                        .GetCredentials();
            }
            catch (Exception ex)
            {
                throw new UploadError(
                    "call connect() before using storage",
                    "validate",
                    null,
                    ex);
            }

            try
            {
                var auth =
                    Auth.GetInstance();

                var authData =
                    await auth.Authenticate();

                // Kotlin:
                // ${Constant.BASE_URL.removeSuffix("/ws")}/api/${enc(org)}/storage
                string baseUrl =
                    ArtConstants.BASE_URL
                        .TrimEnd('/');

                if (baseUrl.EndsWith(
                    "/ws",
                    StringComparison.OrdinalIgnoreCase))
                {
                    baseUrl =
                        baseUrl.Substring(
                            0,
                            baseUrl.Length - 3);
                }

                baseUrl +=
                    "/api/" +
                    Escape(credentials.OrgTitle) +
                    "/storage";

                using var request =
                    new UnityWebRequest(
                        baseUrl + path,
                        method.ToUpperInvariant());

                request.downloadHandler =
                    new DownloadHandlerBuffer();

                if (body != null)
                {
                    byte[] bodyBytes =
                        Encoding.UTF8.GetBytes(
                            JsonConvert.SerializeObject(body));

                    request.uploadHandler =
                        new UploadHandlerRaw(bodyBytes);

                    request.SetRequestHeader(
                        "Content-Type",
                        "application/json");
                }
                else if (
                    method.Equals(
                        "POST",
                        StringComparison.OrdinalIgnoreCase) ||
                    method.Equals(
                        "PUT",
                        StringComparison.OrdinalIgnoreCase) ||
                    method.Equals(
                        "PATCH",
                        StringComparison.OrdinalIgnoreCase))
                {
                    // Kotlin sends an empty RequestBody for POST/PUT/PATCH
                    // when body == null.
                    request.uploadHandler =
                        new UploadHandlerRaw(
                            Array.Empty<byte>());
                }

                request.SetRequestHeader(
                    "Authorization",
                    "Bearer " +
                    authData.AccessToken);

                request.SetRequestHeader(
                    "Accept",
                    "application/json");

                request.SetRequestHeader(
                    "X-Org",
                    credentials.OrgTitle);

                request.SetRequestHeader(
                    "Environment",
                    credentials.Environment);

                request.SetRequestHeader(
                    "ProjectKey",
                    credentials.ProjectKey);

                // Kotlin timeoutMs -> milliseconds.
                // UnityWebRequest.timeout is seconds.
                if (timeoutMs.HasValue)
                {
                    request.timeout =
                        Math.Max(
                            1,
                            (int)Math.Ceiling(
                                timeoutMs.Value / 1000.0));
                }

                var operationRequest =
                    request.SendWebRequest();

                while (!operationRequest.isDone)
                    await Task.Yield();

                if (request.responseCode < 200 ||
                    request.responseCode >= 300)
                {
                    throw new UploadError(
                        "storage " +
                        operation +
                        " failed: HTTP " +
                        request.responseCode +
                        " " +
                        DescribeRequestError(request),
                        operation,
                        request.responseCode);
                }

                string text =
                    request.downloadHandler
                        ?.text
                        .Trim();

                if (string.IsNullOrWhiteSpace(text))
                    return new JObject();

                var root =
                    JObject.Parse(text);

                return root["data"] as JObject
                       ?? new JObject();
            }
            catch (UploadError)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new UploadError(
                    "storage " +
                    operation +
                    " failed: " +
                    ex.Message,
                    operation,
                    null,
                    ex);
            }
        }

        private static async Task PutToStorage(
            string url,
            byte[] file,
            string contentType,
            UploadOptions options)
        {
            // Kotlin default is 60,000 ms.
            long timeoutMs =
                options.TimeoutMs
                ?? 60_000L;

            options.OnProgress?.Invoke(0f);

            try
            {
                using var request =
                    new UnityWebRequest(
                        url,
                        UnityWebRequest.kHttpVerbPUT);

                request.uploadHandler =
                    new UploadHandlerRaw(file)
                    {
                        contentType = contentType
                    };

                request.downloadHandler =
                    new DownloadHandlerBuffer();

                request.SetRequestHeader(
                    "x-ms-blob-type",
                    "BlockBlob");

                request.SetRequestHeader(
                    "Content-Type",
                    contentType);

                request.timeout =
                    Math.Max(
                        1,
                        (int)Math.Ceiling(
                            timeoutMs / 1000.0));

                var operation =
                    request.SendWebRequest();

                while (!operation.isDone)
                {
                    options.OnProgress?.Invoke(
                        operation.progress);

                    await Task.Yield();
                }

                if (request.responseCode < 200 ||
                    request.responseCode >= 300)
                {
                    throw new UploadError(
                        "storage PUT failed (" +
                        request.responseCode +
                        ")",
                        "put",
                        request.responseCode);
                }

                options.OnProgress?.Invoke(1f);
            }
            catch (UploadError)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new UploadError(
                    "storage PUT failed (network/timeout)",
                    "put",
                    null,
                    ex);
            }
        }

        private static StorageFile ToStorageFile(
            JObject file,
            string readUrl = null)
        {
            return new StorageFile
            {
                FileId =
                    file?["id"]?.ToString()
                    ?? string.Empty,

                Name =
                    file?["original_name"]?.ToString()
                    ?? string.Empty,

                ConfigType =
                    file?["config_type"]?.ToString()
                    ?? string.Empty,

                ConfigId =
                    file?["config_id"]?.ToString()
                    ?? string.Empty,

                Size =
                    file?["file_size"]?.Value<long?>()
                    ?? 0L,

                ContentType =
                    file?["content_type"]?.ToString()
                    ?? string.Empty,

                Status =
                    file?["status"]?.ToString()
                    ?? string.Empty,

                CreatedAt =
                    file?["created_at"]?.ToString()
                    ?? string.Empty,

                ExpiresAt =
                    file?["expires_at"]?.ToString(),

                ReadUrl =
                    readUrl
                    ?? file?["read_url"]?.ToString()
            };
        }

        private static string DescribeRequestError(
            UnityWebRequest request)
        {
            string body =
                request.downloadHandler?.text;

            if (string.IsNullOrWhiteSpace(body))
                return request.error ?? string.Empty;

            return
                (request.error ?? string.Empty) +
                " " +
                body;
        }

        private static string Escape(
            string value)
        {
            return Uri.EscapeDataString(
                value ?? string.Empty);
        }
    }
}
